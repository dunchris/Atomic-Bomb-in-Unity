# Atomic-Bomb-in-Unity

Team members:
1. Christopher Dungo - Designed smoke effect particle systems, initiated repo, worked on paper
2. Alfred Lam - Implemented bloom light effect/fire particle system, worked on paper

Project Instructions: Simply watch what happens!